import { X } from "lucide-react";
import { useState } from "react";

export function AdBanner() {
  const [dismissed, setDismissed] = useState(false);
  if (dismissed) return null;
  return (
    <div className="relative bg-gray-100 border border-[#E5E7EB] rounded-xl h-[60px] flex items-center justify-center text-xs text-gray-500">
      <span className="absolute top-1.5 left-2 text-[9px] uppercase tracking-wide text-gray-400">Advertisement</span>
      <span className="font-medium">Your local shops, delivered fast 🛵</span>
      <button onClick={() => setDismissed(true)} className="absolute top-1 right-1 w-5 h-5 flex items-center justify-center text-gray-400">
        <X size={12} />
      </button>
    </div>
  );
}
