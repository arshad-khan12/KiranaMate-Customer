import { Minus, Plus } from "lucide-react";
import { useCart } from "../lib/store";
import type { Product } from "../lib/data";

export function QtyPill({ product, size = "sm" }: { product: Product; size?: "sm" | "md" }) {
  const { qtyOf, add, setQty } = useCart();
  const qty = qtyOf(product.id);
  const dim = size === "md" ? "h-10" : "h-9";
  const btn = size === "md" ? "w-10 h-10" : "w-9 h-9";
  const icon = size === "md" ? 18 : 16;

  if (qty === 0) {
    return (
      <button
        onClick={() => add(product)}
        className={`bg-[#2E7D32] hover:bg-[#256528] text-white rounded-full ${btn} flex items-center justify-center shadow-sm animate-scale-in`}
        aria-label="add to cart"
      >
        <Plus size={icon + 2} />
      </button>
    );
  }

  return (
    <div className={`flex items-center bg-[#2E7D32] text-white rounded-full ${dim} px-1 shadow-sm animate-scale-in`}>
      <button
        onClick={() => setQty(product.id, qty - 1)}
        className={`${btn} flex items-center justify-center`}
        aria-label="decrease"
      >
        <Minus size={icon} />
      </button>
      <span className="font-bold text-sm min-w-[20px] text-center select-none">{qty}</span>
      <button
        onClick={() => setQty(product.id, qty + 1)}
        className={`${btn} flex items-center justify-center`}
        aria-label="increase"
      >
        <Plus size={icon} />
      </button>
    </div>
  );
}
