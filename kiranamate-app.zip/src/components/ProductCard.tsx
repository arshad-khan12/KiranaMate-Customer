import { Link } from "@tanstack/react-router";
import { Star, Heart, Trash2 } from "lucide-react";
import type { Product } from "../lib/data";
import { useCart, useWish } from "../lib/store";
import { QtyPill } from "./QtyPill";

export function ProductCard({ product, onRemoveWish }: { product: Product; showWishlist?: boolean; onRemoveWish?: () => void }) {
  const { has, toggle } = useWish();
  const liked = has(product.id);

  return (
    <div className="bg-white rounded-2xl border border-[#E5E7EB] p-3 flex flex-col relative">
      <button
        onClick={() => (onRemoveWish ? onRemoveWish() : toggle(product.id))}
        className="absolute top-2 right-2 z-10"
        aria-label="wishlist"
      >
        <Heart size={18} className={liked ? "fill-red-500 text-red-500" : "text-gray-300"} />
      </button>
      <Link to="/product/$id" params={{ id: String(product.id) }} className="flex flex-col items-center">
        <div className="text-5xl my-2">{product.image}</div>
        <span className="text-[10px] bg-green-50 text-[#2E7D32] px-2 py-0.5 rounded-full font-medium">
          {product.category}
        </span>
        <h3 className="text-sm font-semibold text-gray-800 mt-2 text-center line-clamp-2 min-h-[40px]">
          {product.name}
        </h3>
      </Link>
      <div className="flex items-center gap-1 mt-1">
        <Star size={12} className="fill-yellow-400 text-yellow-400" />
        <span className="text-xs text-gray-600">{product.rating}</span>
        <span className="text-xs text-gray-400">({product.reviews})</span>
      </div>
      <div className="flex items-center justify-between mt-2">
        <div>
          <span className="text-xs text-gray-400 line-through">₹{product.oldPrice}</span>
          <div className="text-base font-bold text-[#2E7D32]">₹{product.price}</div>
        </div>
        <QtyPill product={product} />
      </div>
    </div>
  );
}

export function CartLineItem({ id }: { id: number }) {
  const { items, remove } = useCart();
  const item = items.find((i) => i.product.id === id);
  if (!item) return null;
  const p = item.product;
  const lineTotal = p.price * item.qty;
  return (
    <div className="bg-white rounded-2xl border border-[#E5E7EB] p-3 flex gap-3 items-center">
      <div className="text-4xl">{p.image}</div>
      <div className="flex-1 min-w-0">
        <h4 className="text-sm font-semibold truncate">{p.name}</h4>
        <p className="text-xs text-gray-400">per {p.unit} · ₹{p.price}</p>
        <div className="text-sm font-bold text-[#2E7D32] mt-0.5">₹{lineTotal}</div>
      </div>
      <div className="flex flex-col items-end gap-2">
        <button onClick={() => remove(p.id)} aria-label="remove">
          <Trash2 size={16} className="text-gray-400" />
        </button>
        <QtyPill product={p} />
      </div>
    </div>
  );
}
