import { Link, useRouterState } from "@tanstack/react-router";
import { ShoppingCart } from "lucide-react";
import { useCart } from "../lib/store";

const HIDDEN = ["/", "/cart", "/checkout", "/order-success", "/signin", "/signup"];

export function FloatingCartBar() {
  const { count, subtotal } = useCart();
  const path = useRouterState({ select: (s) => s.location.pathname });

  if (count === 0) return null;
  if (HIDDEN.includes(path)) return null;

  return (
    <Link
      to="/cart"
      className="fixed left-1/2 -translate-x-1/2 w-full max-w-[390px] px-4 z-40"
      style={{ bottom: "calc(4rem + 8px)" }}
    >
      <div
        className="flex items-center justify-between bg-[#2E7D32] text-white rounded-2xl px-5 py-3.5 animate-slide-in-up"
        style={{ boxShadow: "0 4px 20px rgba(0,0,0,0.25)" }}
      >
        <div className="flex items-center gap-2 font-bold text-sm">
          <ShoppingCart size={18} />
          <span>{count} item{count !== 1 ? "s" : ""}</span>
          <span className="opacity-80">·</span>
          <span>₹{subtotal}</span>
        </div>
        <span className="font-bold text-sm">View Cart →</span>
      </div>
    </Link>
  );
}
