import { Link, useRouterState } from "@tanstack/react-router";
import { Home, Search, ShoppingCart, User } from "lucide-react";
import { useCart } from "../lib/store";

export function BottomNav() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const { count } = useCart();

  const items = [
    { to: "/shops", icon: Home, label: "Shops" },
    { to: "/search", icon: Search, label: "Search" },
    { to: "/cart", icon: ShoppingCart, label: "Cart" },
    { to: "/profile", icon: User, label: "Profile" },
  ] as const;

  return (
    <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[390px] bg-white border-t border-[#E5E7EB] flex justify-around items-center h-16 z-50">
      {items.map(({ to, icon: Icon, label }) => {
        const active = path === to;
        return (
          <Link key={to} to={to} className="flex flex-col items-center gap-0.5 relative px-3 py-1">
            <div className="relative">
              <Icon size={22} className={active ? "text-[#2E7D32]" : "text-gray-400"} />
              {to === "/cart" && count > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-[10px] font-bold rounded-full min-w-[18px] h-[18px] px-1 flex items-center justify-center">
                  {count}
                </span>
              )}
            </div>
            <span className={`text-[10px] ${active ? "text-[#2E7D32] font-semibold" : "text-gray-400"}`}>{label}</span>
          </Link>
        );
      })}
    </nav>
  );
}
