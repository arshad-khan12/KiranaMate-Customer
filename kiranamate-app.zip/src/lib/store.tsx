import { createContext, useContext, useMemo, useState, type ReactNode } from "react";
import type { Product } from "./data";

type CartItem = { product: Product; qty: number };

type CartCtx = {
  items: CartItem[];
  count: number;
  subtotal: number;
  shopId: string | null;
  setShopId: (id: string | null) => void;
  add: (p: Product, qty?: number) => void;
  remove: (id: number) => void;
  setQty: (id: number, qty: number) => void;
  qtyOf: (id: number) => number;
  clear: () => void;
};

type WishCtx = {
  ids: number[];
  toggle: (id: number) => void;
  has: (id: number) => boolean;
};

const Cart = createContext<CartCtx | null>(null);
const Wish = createContext<WishCtx | null>(null);

export function AppProviders({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [ids, setIds] = useState<number[]>([]);
  const [shopId, setShopId] = useState<string | null>(null);

  const cart: CartCtx = useMemo(() => ({
    items,
    count: items.reduce((s, i) => s + i.qty, 0),
    subtotal: items.reduce((s, i) => s + i.qty * i.product.price, 0),
    shopId,
    setShopId,
    qtyOf: (id: number) => items.find((i) => i.product.id === id)?.qty ?? 0,
    add: (p, qty = 1) =>
      setItems((prev) => {
        const ex = prev.find((i) => i.product.id === p.id);
        return ex
          ? prev.map((i) => (i.product.id === p.id ? { ...i, qty: i.qty + qty } : i))
          : [...prev, { product: p, qty }];
      }),
    remove: (id) => setItems((prev) => prev.filter((i) => i.product.id !== id)),
    setQty: (id, qty) =>
      setItems((prev) =>
        qty <= 0 ? prev.filter((i) => i.product.id !== id) : prev.map((i) => (i.product.id === id ? { ...i, qty } : i))
      ),
    clear: () => setItems([]),
  }), [items, shopId]);

  const wish: WishCtx = useMemo(() => ({
    ids,
    toggle: (id) => setIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id])),
    has: (id) => ids.includes(id),
  }), [ids]);

  return (
    <Wish.Provider value={wish}>
      <Cart.Provider value={cart}>{children}</Cart.Provider>
    </Wish.Provider>
  );
}

export const useCart = () => useContext(Cart)!;
export const useWish = () => useContext(Wish)!;
