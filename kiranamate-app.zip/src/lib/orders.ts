import { addDoc, collection, onSnapshot, query, serverTimestamp, where, doc, type Unsubscribe } from "firebase/firestore";
import { db } from "./firebase";

export type OrderStatus = "pending" | "confirmed" | "preparing" | "out_for_delivery" | "delivered";

export const STATUS_FLOW: OrderStatus[] = ["pending", "confirmed", "preparing", "out_for_delivery", "delivered"];

export const STATUS_LABEL: Record<OrderStatus, string> = {
  pending: "Order Placed",
  confirmed: "Confirmed",
  preparing: "Preparing",
  out_for_delivery: "Out for Delivery",
  delivered: "Delivered",
};

export type OrderItem = {
  name: string;
  qty: number;
  price: number;
  emoji: string;
  unit: string;
};

export type OrderDoc = {
  orderId: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  items: OrderItem[];
  subtotal: number;
  deliveryFee: number;
  grandTotal: number;
  status: OrderStatus;
};

export async function createOrder(data: Omit<OrderDoc, "status"> & { status?: OrderStatus }) {
  const payload = {
    ...data,
    status: data.status ?? "pending",
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };
  await addDoc(collection(db, "orders"), payload);
  return data.orderId;
}

export function subscribeToOrder(orderId: string, cb: (data: OrderDoc | null) => void): Unsubscribe {
  const q = query(collection(db, "orders"), where("orderId", "==", orderId));
  return onSnapshot(q, (snap) => {
    if (snap.empty) return cb(null);
    cb(snap.docs[0].data() as OrderDoc);
  });
}

// reserved for future direct-by-doc-id lookups
export const _docRef = (id: string) => doc(db, "orders", id);
