export type Product = {
  id: number;
  name: string;
  category: string;
  price: number;
  oldPrice: number;
  rating: number;
  reviews: number;
  unit: string;
  image: string;
  inStock: boolean;
};

export const products: Product[] = [
  { id: 1, name: "Tata Salt 1kg", category: "Staples", price: 28, oldPrice: 32, rating: 4.8, reviews: 210, unit: "kg", image: "🧂", inStock: true },
  { id: 2, name: "Aashirvaad Atta 5kg", category: "Staples", price: 285, oldPrice: 320, rating: 4.7, reviews: 189, unit: "pack", image: "🌾", inStock: true },
  { id: 3, name: "Amul Full Cream Milk 1L", category: "Dairy", price: 68, oldPrice: 72, rating: 4.9, reviews: 340, unit: "litre", image: "🥛", inStock: true },
  { id: 4, name: "Amul Butter 500g", category: "Dairy", price: 275, oldPrice: 295, rating: 4.8, reviews: 156, unit: "pack", image: "🧈", inStock: true },
  { id: 5, name: "Fortune Sunflower Oil 1L", category: "Oils", price: 145, oldPrice: 165, rating: 4.6, reviews: 98, unit: "litre", image: "🫙", inStock: true },
  { id: 6, name: "Toor Dal 1kg", category: "Pulses", price: 135, oldPrice: 155, rating: 4.7, reviews: 122, unit: "kg", image: "🫘", inStock: true },
  { id: 7, name: "Chana Dal 1kg", category: "Pulses", price: 110, oldPrice: 130, rating: 4.5, reviews: 87, unit: "kg", image: "🫘", inStock: true },
  { id: 8, name: "Basmati Rice 5kg", category: "Staples", price: 450, oldPrice: 520, rating: 4.8, reviews: 275, unit: "pack", image: "🍚", inStock: true },
  { id: 9, name: "Maggi Noodles 70g", category: "Snacks", price: 14, oldPrice: 16, rating: 4.6, reviews: 510, unit: "piece", image: "🍜", inStock: true },
  { id: 10, name: "Parle-G Biscuits 800g", category: "Snacks", price: 85, oldPrice: 95, rating: 4.7, reviews: 430, unit: "pack", image: "🍪", inStock: true },
  { id: 11, name: "Colgate Toothpaste 200g", category: "Personal Care", price: 138, oldPrice: 155, rating: 4.6, reviews: 203, unit: "piece", image: "🪥", inStock: true },
  { id: 12, name: "Surf Excel 1kg", category: "Detergents", price: 195, oldPrice: 220, rating: 4.7, reviews: 178, unit: "pack", image: "🧺", inStock: true },
  { id: 13, name: "Lifebuoy Soap 100g", category: "Personal Care", price: 38, oldPrice: 45, rating: 4.5, reviews: 145, unit: "piece", image: "🧼", inStock: true },
  { id: 14, name: "Red Label Tea 500g", category: "Beverages", price: 235, oldPrice: 260, rating: 4.8, reviews: 312, unit: "pack", image: "🍵", inStock: true },
  { id: 15, name: "Nescafe Classic 50g", category: "Beverages", price: 185, oldPrice: 210, rating: 4.7, reviews: 267, unit: "pack", image: "☕", inStock: true },
  { id: 16, name: "Haldiram Namkeen 200g", category: "Snacks", price: 55, oldPrice: 65, rating: 4.6, reviews: 198, unit: "pack", image: "🥜", inStock: true },
  { id: 17, name: "MDH Garam Masala 100g", category: "Spices", price: 75, oldPrice: 90, rating: 4.8, reviews: 234, unit: "pack", image: "🌶️", inStock: true },
  { id: 18, name: "Everest Turmeric 200g", category: "Spices", price: 58, oldPrice: 70, rating: 4.7, reviews: 189, unit: "pack", image: "🌿", inStock: true },
  { id: 19, name: "Britannia Bread 400g", category: "Bakery", price: 42, oldPrice: 50, rating: 4.5, reviews: 156, unit: "piece", image: "🍞", inStock: true },
  { id: 20, name: "Dettol Handwash 200ml", category: "Personal Care", price: 95, oldPrice: 110, rating: 4.8, reviews: 287, unit: "piece", image: "🧴", inStock: true },
];

export const categories = [
  "All", "Staples", "Dairy", "Pulses", "Oils", "Snacks", "Beverages", "Spices", "Personal Care", "Detergents", "Bakery",
];

export function describe(p: Product) {
  return `${p.name} — a trusted everyday essential from the ${p.category.toLowerCase()} aisle. Freshly sourced, quality checked, and delivered to your doorstep within minutes. Perfect for daily use in every Indian kitchen.`;
}
