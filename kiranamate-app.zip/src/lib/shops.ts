export type Slot = {
  id: string;
  label: string;
  time: string;
  cutoff: string;
  max: number;
  booked: number;
  status: "open" | "full" | "closed";
};

export type Shop = {
  id: string;
  name: string;
  area: string;
  rating: number;
  reviews: number;
  distance: string;
  isOpen: boolean;
  deliveryFee: number;
  freeDeliveryAbove: number;
  minOrder: number;
  nextSlot: string;
  phone: string;
  isFeatured: boolean;
  isSuperShop: boolean;
  slots: Slot[];
};

export const shops: Shop[] = [
  {
    id: "SHOP-01", name: "KiranaMate - Dharampeth", area: "Dharampeth, Nagpur",
    rating: 4.8, reviews: 156, distance: "0.8 km", isOpen: true, deliveryFee: 30,
    freeDeliveryAbove: 500, minOrder: 100, nextSlot: "1:00 PM - 2:00 PM",
    phone: "9876543210", isFeatured: true, isSuperShop: true,
    slots: [
      { id: "S1", label: "Slot 1", time: "10:00-11:00 AM", cutoff: "9:30 AM", max: 15, booked: 8, status: "open" },
      { id: "S2", label: "Slot 2", time: "1:00-2:00 PM", cutoff: "12:30 PM", max: 15, booked: 3, status: "open" },
      { id: "S3", label: "Slot 3", time: "5:00-6:00 PM", cutoff: "4:30 PM", max: 15, booked: 0, status: "open" },
      { id: "S4", label: "Slot 4", time: "8:00-9:00 PM", cutoff: "7:30 PM", max: 15, booked: 0, status: "open" },
    ],
  },
  {
    id: "SHOP-02", name: "Sharma General Store", area: "Sitabuldi, Nagpur",
    rating: 4.6, reviews: 89, distance: "1.2 km", isOpen: true, deliveryFee: 20,
    freeDeliveryAbove: 400, minOrder: 150, nextSlot: "5:00 PM - 6:00 PM",
    phone: "9823456710", isFeatured: false, isSuperShop: false,
    slots: [
      { id: "S1", label: "Slot 1", time: "1:00-2:00 PM", cutoff: "12:30 PM", max: 10, booked: 10, status: "full" },
      { id: "S2", label: "Slot 2", time: "5:00-6:00 PM", cutoff: "4:30 PM", max: 10, booked: 4, status: "open" },
      { id: "S3", label: "Slot 3", time: "8:00-9:00 PM", cutoff: "7:30 PM", max: 10, booked: 0, status: "open" },
    ],
  },
  {
    id: "SHOP-03", name: "Patil Kirana", area: "Ramdaspeth, Nagpur",
    rating: 4.9, reviews: 203, distance: "2.1 km", isOpen: false, deliveryFee: 0,
    freeDeliveryAbove: 0, minOrder: 200, nextSlot: "Tomorrow 10:00 AM",
    phone: "9765432109", isFeatured: true, isSuperShop: false, slots: [],
  },
  {
    id: "SHOP-04", name: "New Maharashtra Stores", area: "Civil Lines, Nagpur",
    rating: 4.5, reviews: 67, distance: "3.4 km", isOpen: true, deliveryFee: 40,
    freeDeliveryAbove: 600, minOrder: 100, nextSlot: "8:00 PM - 9:00 PM",
    phone: "9898765432", isFeatured: false, isSuperShop: false,
    slots: [
      { id: "S1", label: "Slot 1", time: "8:00-9:00 PM", cutoff: "7:30 PM", max: 12, booked: 2, status: "open" },
    ],
  },
];

export const getShop = (id: string) => shops.find((s) => s.id === id);
