import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { setSoundEnabled, setHapticsEnabled } from "./tactile";

type Theme = "light" | "dark";

type SettingsCtx = {
  sound: boolean;
  haptics: boolean;
  theme: Theme;
  setSound: (v: boolean) => void;
  setHaptics: (v: boolean) => void;
  setTheme: (t: Theme) => void;
};

const Ctx = createContext<SettingsCtx | null>(null);

function readLS<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const v = localStorage.getItem(key);
    return v == null ? fallback : (JSON.parse(v) as T);
  } catch {
    return fallback;
  }
}

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [sound, setSound] = useState<boolean>(() => readLS("km.sound", true));
  const [haptics, setHaptics] = useState<boolean>(() => readLS("km.haptics", true));
  const [theme, setTheme] = useState<Theme>(() => readLS<Theme>("km.theme", "light"));

  useEffect(() => {
    localStorage.setItem("km.sound", JSON.stringify(sound));
    setSoundEnabled(sound);
  }, [sound]);

  useEffect(() => {
    localStorage.setItem("km.haptics", JSON.stringify(haptics));
    setHapticsEnabled(haptics);
  }, [haptics]);

  useEffect(() => {
    localStorage.setItem("km.theme", JSON.stringify(theme));
    const root = document.documentElement;
    root.classList.toggle("dark", theme === "dark");
    root.dataset.theme = theme;
  }, [theme]);

  return (
    <Ctx.Provider value={{ sound, haptics, theme, setSound, setHaptics, setTheme }}>
      {children}
    </Ctx.Provider>
  );
}

export function useSettings() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useSettings must be used inside SettingsProvider");
  return v;
}

export function getHapticsEnabled() {
  return readLS<boolean>("km.haptics", true);
}
