import { useEffect, useState } from "react";
import { collection, getDocs, writeBatch, doc } from "firebase/firestore";
import { db } from "./firebase";
import { products as seedProducts, type Product } from "./data";

let cache: Product[] | null = null;
let inflight: Promise<Product[]> | null = null;

async function loadProducts(): Promise<Product[]> {
  if (cache) return cache;
  if (inflight) return inflight;
  inflight = (async () => {
    const snap = await getDocs(collection(db, "products"));
    if (snap.empty) {
      const batch = writeBatch(db);
      seedProducts.forEach((p) => {
        batch.set(doc(db, "products", String(p.id)), p);
      });
      await batch.commit();
      cache = seedProducts;
      return seedProducts;
    }
    const list: Product[] = snap.docs.map((d) => d.data() as Product);
    list.sort((a, b) => a.id - b.id);
    cache = list;
    return list;
  })();
  return inflight;
}

export function useProducts(): Product[] {
  const [list, setList] = useState<Product[]>(cache ?? seedProducts);
  useEffect(() => {
    let alive = true;
    loadProducts()
      .then((data) => {
        if (alive) setList(data);
      })
      .catch((err) => console.error("[products] load failed", err));
    return () => {
      alive = false;
    };
  }, []);
  return list;
}
