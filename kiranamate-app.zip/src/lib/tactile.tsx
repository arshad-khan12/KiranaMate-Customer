import { useEffect } from "react";

let ctx: AudioContext | null = null;
let lastAt = 0;
let soundEnabled = true;
let hapticsEnabled = true;

if (typeof window !== "undefined") {
  try {
    const s = localStorage.getItem("km.sound");
    if (s != null) soundEnabled = JSON.parse(s);
    const h = localStorage.getItem("km.haptics");
    if (h != null) hapticsEnabled = JSON.parse(h);
  } catch {}
}

export function setSoundEnabled(v: boolean) { soundEnabled = v; }
export function setHapticsEnabled(v: boolean) { hapticsEnabled = v; }

function getCtx(): AudioContext | null {
  if (typeof window === "undefined") return null;
  const AC = (window.AudioContext || (window as any).webkitAudioContext) as typeof AudioContext | undefined;
  if (!AC) return null;
  if (!ctx) ctx = new AC();
  if (ctx.state === "suspended") ctx.resume().catch(() => {});
  return ctx;
}

type Variant = "tik" | "tuk" | "tak";

export function playTick(variant: Variant = "tik") {
  if (!soundEnabled) return;
  const c = getCtx();
  if (!c) return;
  const now = c.currentTime;

  // Soft iOS-like pop: sine carrier with a quick pitch dip + gentle envelope + lowpass.
  const base = variant === "tik" ? 1320 : variant === "tuk" ? 620 : 980;
  const dur = variant === "tuk" ? 0.13 : 0.09;
  const peak = variant === "tuk" ? 0.09 : 0.06;

  const osc = c.createOscillator();
  osc.type = "sine";
  osc.frequency.setValueAtTime(base * 1.15, now);
  osc.frequency.exponentialRampToValueAtTime(base * 0.7, now + dur);

  const lp = c.createBiquadFilter();
  lp.type = "lowpass";
  lp.frequency.value = 2600;
  lp.Q.value = 0.4;

  const gain = c.createGain();
  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.exponentialRampToValueAtTime(peak, now + 0.012);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + dur);

  osc.connect(lp).connect(gain).connect(c.destination);
  osc.start(now);
  osc.stop(now + dur + 0.02);
}

export function vibrate(ms: number | number[] = 12) {
  if (!hapticsEnabled) return;
  if (typeof navigator !== "undefined" && "vibrate" in navigator) {
    try { (navigator as any).vibrate(ms); } catch {}
  }
}

export function tap(variant: Variant = "tik", vib: number | number[] = 12) {
  playTick(variant);
  vibrate(vib);
}

function pickVariant(el: Element): Variant {
  const tag = el.tagName.toLowerCase();
  const role = el.getAttribute("role");
  const explicit = (el.closest("[data-tap]") as HTMLElement | null)?.dataset.tap as Variant | undefined;
  if (explicit && ["tik", "tuk", "tak"].includes(explicit)) return explicit;
  if (tag === "a" || role === "link") return "tak";
  const text = (el.textContent || "").trim().toLowerCase();
  if (/(add|place|checkout|pay|order|sign|continue)/.test(text)) return "tuk";
  return "tik";
}

export function TactileFeedback() {
  useEffect(() => {
    const handler = (e: Event) => {
      const target = e.target as Element | null;
      if (!target) return;
      const el = target.closest(
        "button, a, [role='button'], [role='link'], input[type='checkbox'], input[type='radio'], [data-tap]"
      );
      if (!el) return;
      if ((el as HTMLButtonElement).disabled) return;
      const now = Date.now();
      if (now - lastAt < 40) return;
      lastAt = now;
      const variant = pickVariant(el);
      tap(variant, variant === "tuk" ? [10, 30, 14] : 12);
    };
    const opts: AddEventListenerOptions = { capture: true, passive: true };
    document.addEventListener("pointerdown", handler, opts);
    return () => document.removeEventListener("pointerdown", handler, opts as any);
  }, []);
  return null;
}
