import { initializeApp, getApps, getApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth, GoogleAuthProvider, browserLocalPersistence, setPersistence } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyAzjO3oA2WwdeP3YJmtUojCEg-f7CeCFww",
  authDomain: "kiranamate12.firebaseapp.com",
  projectId: "kiranamate12",
  storageBucket: "kiranamate12.firebasestorage.app",
  messagingSenderId: "823359039423",
  appId: "1:823359039423:web:a95600b67832deb714630a",
};

const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

if (typeof window !== "undefined") {
  setPersistence(auth, browserLocalPersistence).catch((e) => console.warn("[auth] persistence", e));
}
