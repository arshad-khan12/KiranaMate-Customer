import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut as fbSignOut,
  sendPasswordResetEmail,
  onAuthStateChanged,
  type User as FbUser,
} from "firebase/auth";
import { doc, getDoc, setDoc, updateDoc, arrayUnion, arrayRemove, serverTimestamp } from "firebase/firestore";
import { auth, db, googleProvider } from "./firebase";

export type Plan = "free" | "pro";

export type Device = {
  deviceId: string;
  deviceName: string;
  lastSeen: number;
  isActive: boolean;
};

export type UserDoc = {
  name: string;
  email: string;
  phone?: string;
  city?: string;
  plan: Plan;
  planExpiry?: number | null;
  trialUsed: boolean;
  devices: Device[];
  maxDevices: number;
  createdAt?: number;
};

type AuthCtx = {
  fbUser: FbUser | null;
  userDoc: UserDoc | null;
  loading: boolean;
  // Compatibility with old store.useAuth
  name: string;
  email: string;
  plan: Plan;
  isPro: boolean;
  // Actions
  signUpEmail: (data: { name: string; email: string; phone: string; password: string; city: string }) => Promise<void>;
  signInEmail: (email: string, password: string) => Promise<void>;
  signInGoogle: () => Promise<void>;
  sendReset: (email: string) => Promise<void>;
  signOut: () => Promise<void>;
  activateTrial: () => Promise<void>;
};

const Ctx = createContext<AuthCtx | null>(null);

const DEVICE_KEY = "km_device_id";
const DEVICE_NAME_KEY = "km_device_name";

function getDeviceId(): string {
  if (typeof window === "undefined") return "ssr";
  let id = localStorage.getItem(DEVICE_KEY);
  if (!id) {
    id = "dev_" + Math.random().toString(36).slice(2) + Date.now().toString(36);
    localStorage.setItem(DEVICE_KEY, id);
  }
  return id;
}

function getDeviceName(): string {
  if (typeof window === "undefined") return "Unknown";
  const cached = localStorage.getItem(DEVICE_NAME_KEY);
  if (cached) return cached;
  const ua = navigator.userAgent;
  let name = "Browser";
  if (/iPhone/.test(ua)) name = "iPhone";
  else if (/iPad/.test(ua)) name = "iPad";
  else if (/Android/.test(ua)) name = "Android";
  else if (/Mac/.test(ua)) name = "Mac";
  else if (/Windows/.test(ua)) name = "Windows";
  const browser = /Chrome/.test(ua) ? "Chrome" : /Firefox/.test(ua) ? "Firefox" : /Safari/.test(ua) ? "Safari" : "Browser";
  const full = `${browser} on ${name}`;
  localStorage.setItem(DEVICE_NAME_KEY, full);
  return full;
}

export class DeviceLimitError extends Error {
  constructor(public used: number, public max: number) {
    super(`Device limit reached (${used}/${max}).`);
  }
}

async function ensureUserDoc(fbUser: FbUser, extras?: { name?: string; phone?: string; city?: string }): Promise<UserDoc> {
  const ref = doc(db, "users", fbUser.uid);
  const snap = await getDoc(ref);
  if (snap.exists()) return snap.data() as UserDoc;
  const data: UserDoc = {
    name: extras?.name || fbUser.displayName || (fbUser.email?.split("@")[0] ?? "Friend"),
    email: fbUser.email || "",
    phone: extras?.phone || fbUser.phoneNumber || "",
    city: extras?.city || "Nagpur",
    plan: "free",
    planExpiry: null,
    trialUsed: false,
    devices: [],
    maxDevices: 1,
  };
  await setDoc(ref, { ...data, createdAt: serverTimestamp() });
  return data;
}

async function registerDevice(uid: string): Promise<UserDoc> {
  const ref = doc(db, "users", uid);
  const snap = await getDoc(ref);
  const u = snap.data() as UserDoc;
  const deviceId = getDeviceId();
  const deviceName = getDeviceName();
  const existing = (u.devices || []).find((d) => d.deviceId === deviceId);
  const maxDevices = u.plan === "pro" ? 3 : 1;

  if (!existing && (u.devices?.length || 0) >= maxDevices) {
    throw new DeviceLimitError(u.devices.length, maxDevices);
  }

  const updatedDevices = existing
    ? u.devices.map((d) => (d.deviceId === deviceId ? { ...d, lastSeen: Date.now(), isActive: true } : d))
    : [...(u.devices || []), { deviceId, deviceName, lastSeen: Date.now(), isActive: true }];

  await updateDoc(ref, { devices: updatedDevices, maxDevices });
  return { ...u, devices: updatedDevices, maxDevices };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [fbUser, setFbUser] = useState<FbUser | null>(null);
  const [userDoc, setUserDoc] = useState<UserDoc | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (u) => {
      setFbUser(u);
      if (!u) {
        setUserDoc(null);
        setLoading(false);
        return;
      }
      try {
        const ref = doc(db, "users", u.uid);
        const snap = await getDoc(ref);
        if (snap.exists()) setUserDoc(snap.data() as UserDoc);
        else setUserDoc(await ensureUserDoc(u));
      } catch (e) {
        console.error("[auth] load user doc", e);
      } finally {
        setLoading(false);
      }
    });
    return () => unsub();
  }, []);

  const api: AuthCtx = useMemo(() => ({
    fbUser,
    userDoc,
    loading,
    name: userDoc?.name || "Friend",
    email: userDoc?.email || fbUser?.email || "",
    plan: userDoc?.plan || "free",
    isPro: userDoc?.plan === "pro",
    signUpEmail: async ({ name, email, phone, password, city }) => {
      const cred = await createUserWithEmailAndPassword(auth, email, password);
      await ensureUserDoc(cred.user, { name, phone, city });
      const doc2 = await registerDevice(cred.user.uid);
      setUserDoc(doc2);
    },
    signInEmail: async (email, password) => {
      const cred = await signInWithEmailAndPassword(auth, email, password);
      await ensureUserDoc(cred.user);
      const doc2 = await registerDevice(cred.user.uid);
      setUserDoc(doc2);
    },
    signInGoogle: async () => {
      const cred = await signInWithPopup(auth, googleProvider);
      await ensureUserDoc(cred.user);
      const doc2 = await registerDevice(cred.user.uid);
      setUserDoc(doc2);
    },
    sendReset: async (email) => sendPasswordResetEmail(auth, email),
    signOut: async () => {
      try {
        if (fbUser) {
          const ref = doc(db, "users", fbUser.uid);
          const deviceId = getDeviceId();
          const current = userDoc?.devices?.find((d) => d.deviceId === deviceId);
          if (current) await updateDoc(ref, { devices: arrayRemove(current) });
        }
      } catch (e) { console.warn("[auth] remove device", e); }
      await fbSignOut(auth);
      setUserDoc(null);
    },
    activateTrial: async () => {
      if (!fbUser || !userDoc) return;
      const ref = doc(db, "users", fbUser.uid);
      const expiry = Date.now() + 7 * 24 * 60 * 60 * 1000;
      await updateDoc(ref, { plan: "pro", planExpiry: expiry, trialUsed: true, maxDevices: 3 });
      setUserDoc({ ...userDoc, plan: "pro", planExpiry: expiry, trialUsed: true, maxDevices: 3 });
    },
  }), [fbUser, userDoc, loading]);

  return <Ctx.Provider value={api}>{children}</Ctx.Provider>;
}

export const useAuth = () => {
  const v = useContext(Ctx);
  if (!v) throw new Error("useAuth must be inside <AuthProvider>");
  return v;
};

// Keep arrayUnion import live for future device additions from manager screen
void arrayUnion;
