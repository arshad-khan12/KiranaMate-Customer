import { createFileRoute, useRouter } from "@tanstack/react-router";
import { ArrowLeft, SlidersHorizontal, Search as SearchIcon, X } from "lucide-react";
import { useState } from "react";
import { categories } from "../lib/data";
import { useProducts } from "../lib/products";
import { ProductCard } from "../components/ProductCard";
import { BottomNav } from "../components/BottomNav";

export const Route = createFileRoute("/search")({ component: SearchPage });

function SearchPage() {
  const router = useRouter();
  const [q, setQ] = useState("");
  const [recent, setRecent] = useState<string[]>(["Atta", "Milk", "Maggi"]);
  const products = useProducts();

  const results = q
    ? products.filter(
        (p) => p.name.toLowerCase().includes(q.toLowerCase()) || p.category.toLowerCase().includes(q.toLowerCase())
      )
    : [];

  return (
    <div className="min-h-screen pb-24">
      <header className="px-5 pt-5 flex items-center gap-3">
        <button onClick={() => router.history.back()} className="w-10 h-10 rounded-full border border-[#E5E7EB] flex items-center justify-center">
          <ArrowLeft size={18} />
        </button>
        <div className="flex-1 flex items-center gap-2 bg-green-50 border border-green-100 rounded-full px-4 py-2.5">
          <SearchIcon size={16} className="text-[#2E7D32]" />
          <input
            autoFocus
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search groceries..."
            className="flex-1 bg-transparent text-sm outline-none"
          />
          {q && <button onClick={() => setQ("")}><X size={16} className="text-gray-400" /></button>}
        </div>
        <button className="w-10 h-10 rounded-full bg-[#2E7D32] text-white flex items-center justify-center">
          <SlidersHorizontal size={16} />
        </button>
      </header>

      {!q && (
        <div className="px-5 mt-6">
          <h3 className="text-sm font-semibold mb-3">Recent Searches</h3>
          <div className="space-y-2">
            {recent.map((r) => (
              <div key={r} className="flex items-center justify-between bg-white rounded-2xl border border-[#E5E7EB] px-4 py-3">
                <button onClick={() => setQ(r)} className="text-sm text-gray-700 flex-1 text-left">{r}</button>
                <button onClick={() => setRecent(recent.filter((x) => x !== r))}>
                  <X size={16} className="text-gray-400" />
                </button>
              </div>
            ))}
          </div>

          <h3 className="text-sm font-semibold mt-6 mb-3">Browse Categories</h3>
          <div className="flex flex-wrap gap-2">
            {categories.filter((c) => c !== "All").map((c) => (
              <button
                key={c}
                onClick={() => setQ(c)}
                className="px-4 py-1.5 rounded-full text-xs font-medium bg-white border border-[#E5E7EB] text-gray-700"
              >{c}</button>
            ))}
          </div>
        </div>
      )}

      {q && results.length > 0 && (
        <div className="px-5 mt-5 grid grid-cols-2 gap-3">
          {results.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      )}

      {q && results.length === 0 && (
        <div className="px-5 mt-16 text-center">
          <div className="text-5xl mb-2">🔍</div>
          <p className="text-gray-500 text-sm">No products found for "{q}"</p>
        </div>
      )}

      <BottomNav />
    </div>
  );
}
