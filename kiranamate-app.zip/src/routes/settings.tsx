import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Volume2, Vibrate, Sun, Moon, Monitor } from "lucide-react";
import { useSettings } from "../lib/settings";

export const Route = createFileRoute("/settings")({ component: Settings });

function Toggle({ on, onChange }: { on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      role="switch"
      aria-checked={on}
      onClick={() => onChange(!on)}
      className={`relative w-11 h-6 rounded-full transition-colors ${on ? "bg-[#2E7D32]" : "bg-gray-300 dark:bg-gray-600"}`}
    >
      <span
        className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${on ? "translate-x-5" : ""}`}
      />
    </button>
  );
}

function Settings() {
  const { sound, haptics, theme, setSound, setHaptics, setTheme } = useSettings();

  return (
    <div className="min-h-screen pb-20 bg-[#F9F9F9] dark:bg-[#0B0F0E]">
      <header className="flex items-center gap-3 px-5 pt-6 pb-4">
        <Link to="/profile" className="w-9 h-9 rounded-full bg-white dark:bg-[#1a1f1d] border border-[#E5E7EB] dark:border-white/10 flex items-center justify-center">
          <ArrowLeft size={18} />
        </Link>
        <h1 className="text-lg font-bold dark:text-white">Settings</h1>
      </header>

      <section className="mx-5 mt-2">
        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide px-1 mb-2">Feedback</p>
        <div className="bg-white dark:bg-[#1a1f1d] rounded-2xl border border-[#E5E7EB] dark:border-white/10 overflow-hidden">
          <div className="flex items-center gap-3 px-4 py-3.5">
            <div className="w-9 h-9 rounded-full bg-green-50 dark:bg-green-900/30 flex items-center justify-center">
              <Volume2 size={16} className="text-[#2E7D32]" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium dark:text-white">Tap sounds</p>
              <p className="text-xs text-gray-500">Soft clicks on every tap</p>
            </div>
            <Toggle on={sound} onChange={setSound} />
          </div>
          <div className="flex items-center gap-3 px-4 py-3.5 border-t border-[#E5E7EB] dark:border-white/10">
            <div className="w-9 h-9 rounded-full bg-green-50 dark:bg-green-900/30 flex items-center justify-center">
              <Vibrate size={16} className="text-[#2E7D32]" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium dark:text-white">Vibration</p>
              <p className="text-xs text-gray-500">Subtle haptic on interactions</p>
            </div>
            <Toggle on={haptics} onChange={setHaptics} />
          </div>
        </div>
      </section>

      <section className="mx-5 mt-6">
        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide px-1 mb-2">Appearance</p>
        <div className="bg-white dark:bg-[#1a1f1d] rounded-2xl border border-[#E5E7EB] dark:border-white/10 p-2 grid grid-cols-2 gap-2">
          {([
            { id: "light", label: "Light", Icon: Sun },
            { id: "dark", label: "Dark", Icon: Moon },
          ] as const).map(({ id, label, Icon }) => {
            const active = theme === id;
            return (
              <button
                key={id}
                onClick={() => setTheme(id)}
                className={`flex flex-col items-center gap-2 py-4 rounded-xl border transition ${
                  active
                    ? "bg-[#2E7D32] text-white border-[#2E7D32]"
                    : "bg-white dark:bg-[#10130f] text-gray-700 dark:text-gray-200 border-[#E5E7EB] dark:border-white/10"
                }`}
              >
                <Icon size={20} />
                <span className="text-xs font-semibold">{label}</span>
              </button>
            );
          })}
        </div>
      </section>

      <section className="mx-5 mt-6">
        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide px-1 mb-2">About</p>
        <div className="bg-white dark:bg-[#1a1f1d] rounded-2xl border border-[#E5E7EB] dark:border-white/10 px-4 py-3.5 flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-green-50 dark:bg-green-900/30 flex items-center justify-center">
            <Monitor size={16} className="text-[#2E7D32]" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium dark:text-white">KiranaMate</p>
            <p className="text-xs text-gray-500">Version 1.0.0</p>
          </div>
        </div>
      </section>
    </div>
  );
}
