import { createFileRoute, useNavigate, useRouter } from "@tanstack/react-router";
import { ArrowLeft, MapPin } from "lucide-react";
import { useState } from "react";
import { useCart } from "../lib/store";
import { useAuth } from "../lib/auth";
import { createOrder } from "../lib/orders";

export const Route = createFileRoute("/checkout")({ component: Checkout });

const DEFAULT_ADDRESS = "Flat 302, Green Residency, MG Road, Bengaluru — 560001";
const DEFAULT_PHONE = "+91 98765 43210";

function Checkout() {
  const router = useRouter();
  const nav = useNavigate();
  const { name } = useAuth();
  const { items, subtotal, clear } = useCart();
  const [notes, setNotes] = useState("");
  const [placing, setPlacing] = useState(false);

  const delivery = subtotal >= 500 || subtotal === 0 ? 0 : 30;
  const discount = 0;
  const total = subtotal + delivery - discount;

  async function placeOrder() {
    if (items.length === 0 || placing) return;
    setPlacing(true);
    const orderId = "KM-" + Date.now();
    try {
      await createOrder({
        orderId,
        customerName: name || "Friend",
        customerPhone: DEFAULT_PHONE,
        customerAddress: DEFAULT_ADDRESS,
        items: items.map((i) => ({
          name: i.product.name,
          qty: i.qty,
          price: i.product.price,
          emoji: i.product.image,
          unit: i.product.unit,
        })),
        subtotal,
        deliveryFee: delivery,
        grandTotal: total,
      });
      clear();
      nav({ to: "/order-success", search: { orderId } });
    } catch (err) {
      console.error("[checkout] failed to place order", err);
      alert("Could not place order. Please try again.");
      setPlacing(false);
    }
  }

  return (
    <div className="min-h-screen pb-32 bg-[#F9F9F9]">
      <header className="px-5 pt-5 flex items-center gap-3">
        <button onClick={() => router.history.back()} className="w-10 h-10 rounded-full border border-[#E5E7EB] flex items-center justify-center bg-white">
          <ArrowLeft size={18} />
        </button>
        <h1 className="font-bold text-lg">Checkout</h1>
      </header>

      <section className="mx-5 mt-5 bg-white rounded-2xl border border-[#E5E7EB] p-4">
        <div className="flex justify-between items-start">
          <div className="flex gap-2">
            <MapPin size={18} className="text-[#2E7D32] mt-0.5" />
            <div>
              <h3 className="text-sm font-semibold">Delivery Address</h3>
              <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                Flat 302, Green Residency,<br />MG Road, Bengaluru — 560001
              </p>
            </div>
          </div>
          <button className="text-xs text-[#2E7D32] font-semibold">Edit</button>
        </div>
      </section>

      <section className="mx-5 mt-4 bg-white rounded-2xl border border-[#E5E7EB] p-4">
        <h3 className="text-sm font-semibold mb-3">Order Items ({items.length})</h3>
        <div className="space-y-2">
          {items.map((i) => (
            <div key={i.product.id} className="flex justify-between text-sm">
              <span className="text-gray-700">{i.product.image} {i.product.name} × {i.qty}</span>
              <span className="font-medium">₹{i.product.price * i.qty}</span>
            </div>
          ))}
          {items.length === 0 && <p className="text-xs text-gray-400">No items</p>}
        </div>
      </section>

      <section className="mx-5 mt-4 bg-white rounded-2xl border border-[#E5E7EB] p-4">
        <h3 className="text-sm font-semibold mb-2">Special Instructions</h3>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="e.g. Leave at the door, call on arrival..."
          className="w-full text-sm border border-[#E5E7EB] rounded-xl p-3 outline-none resize-none"
          rows={3}
        />
      </section>

      <section className="mx-5 mt-4 bg-white rounded-2xl border border-[#E5E7EB] p-4 space-y-2 text-sm">
        <Row label="Subtotal" value={`₹${subtotal}`} />
        <Row label="Delivery" value={delivery === 0 ? "FREE" : `₹${delivery}`} />
        <Row label="Discount" value={`-₹${discount}`} />
        <div className="border-t border-dashed border-[#E5E7EB] pt-2 flex justify-between font-bold">
          <span>Total</span><span className="text-[#2E7D32]">₹{total}</span>
        </div>
      </section>

      <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[390px] p-4 bg-white border-t border-[#E5E7EB]">
        <button
          onClick={placeOrder}
          disabled={items.length === 0 || placing}
          className="w-full bg-[#2E7D32] disabled:bg-gray-300 text-white font-semibold rounded-full py-3.5"
        >{placing ? "Placing..." : `Place Order · ₹${total}`}</button>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return <div className="flex justify-between"><span className="text-gray-500">{label}</span><span className="font-medium">{value}</span></div>;
}
