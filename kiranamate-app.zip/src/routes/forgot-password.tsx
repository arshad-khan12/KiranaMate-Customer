import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, CheckCircle2 } from "lucide-react";
import { useState } from "react";
import { useAuth } from "../lib/auth";

export const Route = createFileRoute("/forgot-password")({ component: Forgot });

function Forgot() {
  const { sendReset } = useAuth();
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr(""); setBusy(true);
    try {
      await sendReset(email.trim());
      setSent(true);
    } catch (e: unknown) {
      setErr((e as Error)?.message?.replace("Firebase: ", "") || "Could not send reset link");
    } finally { setBusy(false); }
  }

  return (
    <div className="min-h-screen bg-[#F9F9F9] px-5 pt-6">
      <Link to="/signin" className="inline-flex w-10 h-10 rounded-full bg-white border border-[#E5E7EB] items-center justify-center">
        <ArrowLeft size={18} />
      </Link>
      <h1 className="mt-6 text-2xl font-bold">Forgot Password</h1>
      <p className="text-sm text-gray-500 mt-1">Enter your email to reset password</p>

      {sent ? (
        <div className="mt-8 bg-white rounded-2xl border border-[#E5E7EB] p-6 text-center">
          <CheckCircle2 size={56} className="text-[#16A34A] mx-auto" />
          <p className="mt-3 text-sm font-semibold">Reset link sent to your email</p>
          <p className="text-xs text-gray-500 mt-1">Check your inbox and follow the link to set a new password.</p>
          <Link to="/signin" className="inline-block mt-5 bg-[#2E7D32] text-white rounded-full px-6 py-2.5 text-sm font-semibold">Back to Sign In</Link>
        </div>
      ) : (
        <form onSubmit={submit} className="mt-6 space-y-3">
          <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@email.com"
            className="w-full bg-white border border-[#E5E7EB] rounded-2xl px-4 py-3 text-sm outline-none focus:border-[#2E7D32]" />
          {err && <p className="text-xs text-red-600">{err}</p>}
          <button disabled={busy} className="w-full bg-[#2E7D32] disabled:opacity-60 text-white font-semibold rounded-full py-3.5">
            {busy ? "Sending..." : "Send Reset Link"}
          </button>
          <Link to="/signin" className="block text-center text-sm text-[#2E7D32] font-semibold mt-3">Back to Sign In</Link>
        </form>
      )}
    </div>
  );
}
