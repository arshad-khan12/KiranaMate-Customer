import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ShoppingBasket } from "lucide-react";
import { useEffect } from "react";
import { useAuth } from "../lib/auth";

export const Route = createFileRoute("/")({ component: Splash });

function Splash() {
  const nav = useNavigate();
  const { fbUser, loading } = useAuth();

  useEffect(() => {
    const t = setTimeout(() => {
      if (loading) return;
      nav({ to: fbUser ? "/shops" : "/signin" });
    }, 1500);
    return () => clearTimeout(t);
  }, [fbUser, loading, nav]);

  return (
    <div className="min-h-screen bg-[#2E7D32] flex flex-col items-center justify-center text-white px-8">
      <div className="w-24 h-24 rounded-full bg-white flex items-center justify-center shadow-2xl">
        <ShoppingBasket size={48} className="text-[#2E7D32]" />
      </div>
      <h1 className="mt-5 text-3xl font-extrabold tracking-tight">KiranaMate</h1>
      <p className="mt-2 text-white/90 text-sm">Aapka Bharosemand Kirana</p>
      <div className="mt-10 flex gap-1.5">
        <span className="w-2 h-2 rounded-full bg-white animate-bounce" />
        <span className="w-2 h-2 rounded-full bg-white animate-bounce" style={{ animationDelay: "0.15s" }} />
        <span className="w-2 h-2 rounded-full bg-white animate-bounce" style={{ animationDelay: "0.3s" }} />
      </div>
    </div>
  );
}
