import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { ArrowLeft, Heart } from "lucide-react";
import { products } from "../lib/data";
import { useWish } from "../lib/store";
import { QtyPill } from "../components/QtyPill";

export const Route = createFileRoute("/wishlist")({ component: Wishlist });

function Wishlist() {
  const router = useRouter();
  const { ids, toggle } = useWish();

  const list = products.filter((p) => ids.includes(p.id));

  return (
    <div className="min-h-screen pb-16 bg-[#F9F9F9]">
      <header className="px-5 pt-5 flex items-center gap-3">
        <button onClick={() => router.history.back()} className="w-10 h-10 rounded-full border border-[#E5E7EB] flex items-center justify-center bg-white">
          <ArrowLeft size={18} />
        </button>
        <h1 className="font-bold text-lg">My Wishlist</h1>
      </header>

      {list.length === 0 ? (
        <div className="px-6 mt-24 text-center">
          <div className="text-6xl mb-3">💚</div>
          <h2 className="font-bold">Your wishlist is empty</h2>
          <p className="text-sm text-gray-500 mt-1">Tap the heart on any product to save it here.</p>
          <Link to="/home" className="inline-block mt-6 bg-[#2E7D32] text-white font-semibold rounded-full px-6 py-3 text-sm">Browse Products</Link>
        </div>
      ) : (
        <div className="px-5 mt-5 grid grid-cols-2 gap-3">
          {list.map((p) => (
            <div key={p.id} className="bg-white rounded-2xl border border-[#E5E7EB] p-3 flex flex-col relative">
              <button onClick={() => toggle(p.id)} className="absolute top-2 right-2 z-10">
                <Heart size={18} className="fill-red-500 text-red-500" />
              </button>
              <Link to="/product/$id" params={{ id: String(p.id) }} className="flex flex-col items-center">
                <div className="text-5xl my-2">{p.image}</div>
                <span className="text-[10px] bg-green-50 text-[#2E7D32] px-2 py-0.5 rounded-full font-medium">{p.category}</span>
                <h3 className="text-sm font-semibold text-gray-800 mt-2 text-center line-clamp-2 min-h-[40px]">{p.name}</h3>
              </Link>
              <div className="flex items-baseline gap-1 mt-1">
                <span className="text-xs text-gray-400 line-through">₹{p.oldPrice}</span>
                <span className="text-base font-bold text-[#2E7D32]">₹{p.price}</span>
              </div>
              <div className="mt-2 flex justify-end">
                <QtyPill product={p} />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
