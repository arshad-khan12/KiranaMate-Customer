import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Eye, EyeOff, ShoppingBasket } from "lucide-react";
import { useAuth, DeviceLimitError } from "../lib/auth";
import { GoogleIcon } from "./signup";

export const Route = createFileRoute("/signin")({ component: SignIn });

function SignIn() {
  const nav = useNavigate();
  const { signInEmail, signInGoogle } = useAuth();
  const [show, setShow] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [deviceErr, setDeviceErr] = useState<DeviceLimitError | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr(""); setDeviceErr(null); setBusy(true);
    try {
      await signInEmail(email.trim(), password);
      nav({ to: "/shops" });
    } catch (e: unknown) {
      if (e instanceof DeviceLimitError) setDeviceErr(e);
      else setErr((e as Error)?.message?.replace("Firebase: ", "") || "Sign in failed");
    } finally { setBusy(false); }
  }

  async function google() {
    setErr(""); setDeviceErr(null); setBusy(true);
    try {
      await signInGoogle();
      nav({ to: "/shops" });
    } catch (e: unknown) {
      if (e instanceof DeviceLimitError) setDeviceErr(e);
      else setErr((e as Error)?.message?.replace("Firebase: ", "") || "Google sign in failed");
    } finally { setBusy(false); }
  }

  return (
    <div className="min-h-screen bg-[#2E7D32] flex flex-col">
      <div className="pt-10 pb-6 flex flex-col items-center text-white">
        <div className="w-14 h-14 rounded-full bg-white flex items-center justify-center mb-2">
          <ShoppingBasket className="text-[#2E7D32]" />
        </div>
        <h1 className="text-2xl font-bold">Welcome Back</h1>
        <p className="text-white/80 text-xs mt-1">Sign in to continue</p>
      </div>
      <div className="flex-1 bg-white rounded-t-3xl p-6">
        {deviceErr && (
          <div className="mb-4 rounded-2xl border border-red-200 bg-red-50 p-3 text-sm">
            <p className="text-red-700 font-semibold">Device limit reached ({deviceErr.used}/{deviceErr.max})</p>
            <p className="text-red-600 text-xs mt-1">Sign out from another device or upgrade to Pro.</p>
            <Link to="/pro" className="inline-block mt-2 bg-[#2E7D32] text-white rounded-full px-4 py-1.5 text-xs font-semibold">Upgrade to Pro</Link>
          </div>
        )}
        <form onSubmit={submit} className="space-y-3">
          <label className="block">
            <span className="text-xs font-medium text-gray-600">Email</span>
            <input
              type="email" required value={email}
              onChange={(e) => setEmail(e.target.value)} placeholder="you@email.com"
              className="mt-1 w-full bg-white border border-[#E5E7EB] rounded-2xl px-4 py-3 text-sm outline-none focus:border-[#2E7D32]"
            />
          </label>
          <label className="block">
            <span className="text-xs font-medium text-gray-600">Password</span>
            <div className="relative">
              <input
                type={show ? "text" : "password"} required value={password}
                onChange={(e) => setPassword(e.target.value)} placeholder="••••••••"
                className="mt-1 w-full bg-white border border-[#E5E7EB] rounded-2xl px-4 py-3 text-sm outline-none focus:border-[#2E7D32] pr-10"
              />
              <button type="button" onClick={() => setShow(!show)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
                {show ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </label>
          <div className="text-right">
            <Link to="/forgot-password" className="text-xs text-[#2E7D32] font-medium">Forgot password?</Link>
          </div>
          {err && <p className="text-xs text-red-600">{err}</p>}
          <button disabled={busy} className="w-full bg-[#2E7D32] disabled:opacity-60 text-white font-semibold rounded-full py-3.5 mt-2">
            {busy ? "Signing in..." : "Sign In"}
          </button>
        </form>
        <div className="flex items-center gap-3 my-5">
          <div className="flex-1 h-px bg-gray-200" />
          <span className="text-xs text-gray-400">Or sign in with</span>
          <div className="flex-1 h-px bg-gray-200" />
        </div>
        <button type="button" onClick={google} disabled={busy}
          className="w-full border border-gray-200 rounded-full py-3 flex items-center justify-center gap-2 text-sm font-medium disabled:opacity-60">
          <GoogleIcon /> Continue with Google
        </button>
        <p className="text-center text-sm text-gray-500 mt-6">
          New here? <Link to="/signup" className="text-[#2E7D32] font-semibold">Sign Up</Link>
        </p>
      </div>
    </div>
  );
}
