import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ChevronRight, ShoppingBag, Heart, MapPin, Bell, Settings as SettingsIcon, HelpCircle, Shield, Info, LogOut, Crown, Smartphone } from "lucide-react";
import { BottomNav } from "../components/BottomNav";
import { useAuth } from "../lib/auth";

export const Route = createFileRoute("/profile")({ component: Profile });

function Profile() {
  const { name, email, signOut, isPro, userDoc } = useAuth();
  const nav = useNavigate();
  const initials = (name || "U").split(" ").map((n: string) => n[0]).join("").slice(0, 2).toUpperCase();

  const trialDaysLeft = userDoc?.plan === "pro" && userDoc.planExpiry
    ? Math.max(0, Math.ceil((userDoc.planExpiry - Date.now()) / (24 * 60 * 60 * 1000)))
    : 0;

  const menu = [
    { icon: ShoppingBag, label: "My Orders", to: "/order-success" as const },
    { icon: Heart, label: "My Wishlist", to: "/wishlist" as const },
    { icon: SettingsIcon, label: "Settings", to: "/settings" as const },
    { icon: MapPin, label: "Saved Addresses" },
    { icon: Bell, label: "Notifications" },
    { icon: Smartphone, label: `Devices (${userDoc?.devices?.length ?? 0}/${userDoc?.maxDevices ?? 1})` },
    { icon: HelpCircle, label: "Help & Support" },
    { icon: Shield, label: "Privacy Policy" },
    { icon: Info, label: "About KiranaMate" },
  ];

  return (
    <div className="min-h-screen pb-24 bg-[#F9F9F9]">
      <header className="bg-gradient-to-br from-[#2E7D32] to-[#4CAF50] px-5 pt-8 pb-12 text-white text-center rounded-b-3xl">
        <div className="w-20 h-20 rounded-full bg-white text-[#2E7D32] mx-auto flex items-center justify-center text-2xl font-bold">
          {initials}
        </div>
        <h1 className="font-bold mt-3">{name}</h1>
        <p className="text-xs text-white/80">{email}</p>
        <div className="mt-3 flex items-center justify-center gap-2">
          {isPro ? (
            <span className="bg-amber-400 text-amber-900 text-[11px] font-bold px-3 py-1 rounded-full inline-flex items-center gap-1">
              <Crown size={12} /> Pro Member {trialDaysLeft > 0 && `· ${trialDaysLeft}d`}
            </span>
          ) : (
            <span className="bg-white/20 text-white text-[11px] font-semibold px-3 py-1 rounded-full">Free Plan</span>
          )}
        </div>
        {!isPro && (
          <Link to="/pro" className="mt-3 inline-block bg-white text-[#2E7D32] text-xs font-bold rounded-full px-5 py-2">
            👑 Upgrade to Pro
          </Link>
        )}
      </header>

      <div className="mx-5 -mt-6 bg-white dark:bg-[#1a1f1d] rounded-2xl border border-[#E5E7EB] dark:border-white/10 overflow-hidden">
        {menu.map((m, i) => {
          const inner = (
            <div className={`flex items-center gap-3 px-4 py-3.5 ${i !== 0 ? "border-t border-[#E5E7EB] dark:border-white/10" : ""}`}>
              <div className="w-8 h-8 rounded-full bg-green-50 dark:bg-green-900/30 flex items-center justify-center">
                <m.icon size={16} className="text-[#2E7D32] dark:text-[#4CAF50]" />
              </div>
              <span className="flex-1 text-sm text-gray-900 dark:text-gray-100">{m.label}</span>
              <ChevronRight size={16} className="text-gray-400" />
            </div>
          );
          return m.to ? <Link key={m.label} to={m.to}>{inner}</Link> : <div key={m.label}>{inner}</div>;
        })}
      </div>

      <button
        onClick={async () => { await signOut(); nav({ to: "/signin" }); }}
        className="mx-5 mt-6 w-[calc(100%-2.5rem)] flex items-center justify-center gap-2 text-red-500 font-semibold py-3 border border-red-200 rounded-full"
      >
        <LogOut size={16} /> Sign Out
      </button>

      <BottomNav />
    </div>
  );
}
