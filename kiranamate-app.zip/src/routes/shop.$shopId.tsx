import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { ArrowLeft, ShoppingCart, Search } from "lucide-react";
import { useState, useEffect, Fragment } from "react";
import { categories } from "../lib/data";
import { useProducts } from "../lib/products";
import { ProductCard } from "../components/ProductCard";
import { BottomNav } from "../components/BottomNav";
import { useAuth } from "../lib/auth";
import { useCart } from "../lib/store";
import { getShop } from "../lib/shops";
import { AdBanner } from "../components/AdBanner";

export const Route = createFileRoute("/shop/$shopId")({ component: ShopHome });

function ShopHome() {
  const { shopId } = Route.useParams();
  const router = useRouter();
  const shop = getShop(shopId);
  const { name, isPro } = useAuth();
  const { count, setShopId } = useCart();
  const [cat, setCat] = useState("All");
  const products = useProducts();
  const list = cat === "All" ? products : products.filter((p) => p.category === cat);

  useEffect(() => { setShopId(shopId); }, [shopId, setShopId]);

  if (!shop) {
    return (
      <div className="min-h-screen flex items-center justify-center px-6 text-center">
        <div>
          <p className="text-sm text-gray-500">Shop not found.</p>
          <Link to="/shops" className="mt-4 inline-block bg-[#2E7D32] text-white rounded-full px-5 py-2 text-sm font-semibold">Back to Shops</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-28 bg-[#F9F9F9]">
      <header className="bg-white sticky top-0 z-10 px-5 pt-5 pb-3 border-b border-[#F3F4F6]">
        <div className="flex items-center gap-3">
          <button onClick={() => router.history.back()} className="w-9 h-9 rounded-full border border-[#E5E7EB] flex items-center justify-center">
            <ArrowLeft size={18} />
          </button>
          <div className="flex-1 text-center">
            <p className="font-bold text-sm leading-tight">{shop.name}</p>
            <p className="text-[10px] text-gray-500">{shop.area}</p>
          </div>
          <Link to="/cart" className="relative w-9 h-9 rounded-full border border-[#E5E7EB] flex items-center justify-center">
            <ShoppingCart size={16} />
            {count > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold rounded-full min-w-[18px] h-[18px] px-1 flex items-center justify-center">{count}</span>
            )}
          </Link>
        </div>
      </header>

      <div className="px-5 pt-5">
        <h1 className="text-lg font-bold">Hello {name} 👋</h1>
        <p className="text-xs text-gray-500">What do you need today?</p>
      </div>

      <Link to="/search" className="mx-5 mt-3 flex items-center gap-2 bg-white border border-[#E5E7EB] rounded-full px-4 py-2.5">
        <Search size={16} className="text-gray-400" />
        <span className="text-xs text-gray-500">Search in {shop.name}...</span>
      </Link>

      <div className="mt-4 px-5 overflow-x-auto no-scrollbar">
        <div className="flex gap-2 w-max">
          {categories.map((c) => (
            <button key={c} onClick={() => setCat(c)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-medium whitespace-nowrap border ${
                cat === c ? "bg-[#2E7D32] text-white border-[#2E7D32]" : "bg-white text-gray-600 border-[#E5E7EB]"
              }`}>{c}</button>
          ))}
        </div>
      </div>

      <div className="mx-5 mt-4 bg-gradient-to-r from-[#2E7D32] to-[#4CAF50] rounded-2xl p-4 text-white">
        {isPro ? (
          <>
            <p className="text-xs uppercase tracking-wide opacity-80">👑 Pro Member</p>
            <h3 className="font-bold leading-tight mt-0.5">You get priority slots!</h3>
          </>
        ) : (
          <>
            <div className="text-xl">🎉</div>
            <p className="text-xs uppercase tracking-wide opacity-80">First order offer</p>
            <h3 className="font-bold leading-tight">Get 25% off — use SAVE25</h3>
          </>
        )}
      </div>

      <div className="px-5 mt-5 grid grid-cols-2 gap-3">
        {list.map((p, i) => (
          <Fragment key={p.id}>
            <ProductCard product={p} />
            {!isPro && (i + 1) % 6 === 0 && (
              <div className="col-span-2"><AdBanner /></div>
            )}
          </Fragment>
        ))}
      </div>

      <BottomNav />
    </div>
  );
}
