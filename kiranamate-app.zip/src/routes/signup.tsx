import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Eye, EyeOff, ShoppingBasket } from "lucide-react";
import { useAuth, DeviceLimitError } from "../lib/auth";

export const Route = createFileRoute("/signup")({ component: SignUp });

const CITIES = ["Nagpur", "Mumbai", "Pune", "Hyderabad", "Other"];

function SignUp() {
  const nav = useNavigate();
  const { signUpEmail, signInGoogle } = useAuth();
  const [show, setShow] = useState(false);
  const [show2, setShow2] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [city, setCity] = useState("Nagpur");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [deviceErr, setDeviceErr] = useState<DeviceLimitError | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (!name.trim()) errs.name = "Required";
    if (!/^\S+@\S+\.\S+$/.test(email)) errs.email = "Invalid email";
    if (!/^\d{10}$/.test(phone)) errs.phone = "Enter 10 digit number";
    if (password.length < 6) errs.password = "Min 6 characters";
    if (password !== confirm) errs.confirm = "Passwords don't match";
    setErrors(errs);
    if (Object.keys(errs).length) return;

    setBusy(true); setDeviceErr(null);
    try {
      await signUpEmail({ name: name.trim(), email: email.trim(), phone, password, city });
      nav({ to: "/shops" });
    } catch (e: unknown) {
      if (e instanceof DeviceLimitError) setDeviceErr(e);
      else setErrors({ form: (e as Error)?.message?.replace("Firebase: ", "") || "Sign up failed" });
    } finally { setBusy(false); }
  }

  async function google() {
    setBusy(true); setDeviceErr(null);
    try {
      await signInGoogle();
      nav({ to: "/shops" });
    } catch (e: unknown) {
      if (e instanceof DeviceLimitError) setDeviceErr(e);
      else setErrors({ form: (e as Error)?.message?.replace("Firebase: ", "") || "Google sign in failed" });
    } finally { setBusy(false); }
  }

  return (
    <div className="min-h-screen bg-[#2E7D32] flex flex-col">
      <div className="pt-8 pb-5 flex flex-col items-center text-white">
        <div className="w-14 h-14 rounded-full bg-white flex items-center justify-center mb-2">
          <ShoppingBasket className="text-[#2E7D32]" />
        </div>
        <h1 className="text-2xl font-bold">Create Account</h1>
        <p className="text-white/80 text-xs mt-1">Join your local Kirana network</p>
      </div>
      <div className="flex-1 bg-white rounded-t-3xl p-6 pb-10">
        {deviceErr && (
          <div className="mb-4 rounded-2xl border border-red-200 bg-red-50 p-3 text-xs text-red-700">
            Device limit reached. <Link to="/pro" className="font-semibold underline">Upgrade to Pro</Link>
          </div>
        )}
        <form onSubmit={submit} className="space-y-3">
          <Field label="Full Name" value={name} onChange={setName} placeholder="Rahul Sharma" error={errors.name} />
          <Field label="Email" type="email" value={email} onChange={setEmail} placeholder="you@email.com" error={errors.email} />
          <div>
            <span className="text-xs font-medium text-gray-600">Phone Number</span>
            <div className="mt-1 flex items-stretch border border-[#E5E7EB] rounded-2xl overflow-hidden bg-white">
              <span className="px-3 flex items-center text-sm text-gray-600 bg-gray-50 border-r border-[#E5E7EB]">+91</span>
              <input type="tel" inputMode="numeric" maxLength={10} value={phone}
                onChange={(e) => setPhone(e.target.value.replace(/\D/g, ""))}
                placeholder="9876543210" className="flex-1 px-3 py-3 text-sm outline-none" />
            </div>
            {errors.phone && <p className="text-xs text-red-600 mt-1">{errors.phone}</p>}
          </div>
          <PasswordField label="Password" value={password} setValue={setPassword} show={show} setShow={setShow} error={errors.password} />
          <PasswordField label="Confirm Password" value={confirm} setValue={setConfirm} show={show2} setShow={setShow2} error={errors.confirm} />
          <label className="block">
            <span className="text-xs font-medium text-gray-600">City</span>
            <select value={city} onChange={(e) => setCity(e.target.value)}
              className="mt-1 w-full bg-white border border-[#E5E7EB] rounded-2xl px-4 py-3 text-sm outline-none focus:border-[#2E7D32]">
              {CITIES.map((c) => <option key={c}>{c}</option>)}
            </select>
          </label>
          {errors.form && <p className="text-xs text-red-600">{errors.form}</p>}
          <button disabled={busy} className="w-full bg-[#2E7D32] disabled:opacity-60 text-white font-semibold rounded-full py-3.5 mt-2">
            {busy ? "Creating..." : "Create Account"}
          </button>
        </form>
        <div className="flex items-center gap-3 my-5">
          <div className="flex-1 h-px bg-gray-200" />
          <span className="text-xs text-gray-400">Or sign up with</span>
          <div className="flex-1 h-px bg-gray-200" />
        </div>
        <button type="button" onClick={google} disabled={busy}
          className="w-full border border-gray-200 rounded-full py-3 flex items-center justify-center gap-2 text-sm font-medium disabled:opacity-60">
          <GoogleIcon /> Continue with Google
        </button>
        <p className="text-center text-sm text-gray-500 mt-6">
          Already have an account? <Link to="/signin" className="text-[#2E7D32] font-semibold">Sign In</Link>
        </p>
      </div>
    </div>
  );
}

function Field({ label, value, onChange, type = "text", placeholder, error }: { label: string; value: string; onChange: (v: string) => void; type?: string; placeholder?: string; error?: string }) {
  return (
    <label className="block">
      <span className="text-xs font-medium text-gray-600">{label}</span>
      <input type={type} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder}
        className="mt-1 w-full bg-white border border-[#E5E7EB] rounded-2xl px-4 py-3 text-sm outline-none focus:border-[#2E7D32]" />
      {error && <p className="text-xs text-red-600 mt-1">{error}</p>}
    </label>
  );
}

function PasswordField({ label, value, setValue, show, setShow, error }: { label: string; value: string; setValue: (v: string) => void; show: boolean; setShow: (v: boolean) => void; error?: string }) {
  return (
    <label className="block">
      <span className="text-xs font-medium text-gray-600">{label}</span>
      <div className="relative">
        <input type={show ? "text" : "password"} value={value} onChange={(e) => setValue(e.target.value)} placeholder="••••••••"
          className="mt-1 w-full bg-white border border-[#E5E7EB] rounded-2xl px-4 py-3 text-sm outline-none focus:border-[#2E7D32] pr-10" />
        <button type="button" onClick={() => setShow(!show)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
          {show ? <EyeOff size={18} /> : <Eye size={18} />}
        </button>
      </div>
      {error && <p className="text-xs text-red-600 mt-1">{error}</p>}
    </label>
  );
}

export function GoogleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 48 48"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.4 29.3 35.5 24 35.5c-6.4 0-11.5-5.1-11.5-11.5S17.6 12.5 24 12.5c2.9 0 5.6 1.1 7.7 2.9l5.7-5.7C33.6 6.3 29 4.5 24 4.5 13.2 4.5 4.5 13.2 4.5 24S13.2 43.5 24 43.5 43.5 34.8 43.5 24c0-1.2-.1-2.4-.3-3.5z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 16 19 12.5 24 12.5c2.9 0 5.6 1.1 7.7 2.9l5.7-5.7C33.6 6.3 29 4.5 24 4.5 16.3 4.5 9.7 8.9 6.3 14.7z"/><path fill="#4CAF50" d="M24 43.5c5.2 0 9.8-2 13.3-5.2l-6.1-5c-2 1.4-4.5 2.2-7.2 2.2-5.3 0-9.7-3-11.3-7.3l-6.5 5C9.6 39.1 16.2 43.5 24 43.5z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.3-2.3 4.3-4.1 5.8l6.1 5c-1.7 1.5 6.7-4.8 6.7-14.8 0-1.2-.1-2.4-.4-3.5z"/></svg>
  );
}
