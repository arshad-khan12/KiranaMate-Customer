import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, Truck } from "lucide-react";
import { useEffect, useState } from "react";
import { STATUS_FLOW, STATUS_LABEL, subscribeToOrder, type OrderDoc, type OrderStatus } from "../lib/orders";

type Search = { orderId?: string };

export const Route = createFileRoute("/order-success")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    orderId: typeof s.orderId === "string" ? s.orderId : undefined,
  }),
  component: OrderSuccess,
});

function OrderSuccess() {
  const { orderId } = Route.useSearch();
  const [order, setOrder] = useState<OrderDoc | null>(null);

  useEffect(() => {
    if (!orderId) return;
    const unsub = subscribeToOrder(orderId, setOrder);
    return () => unsub();
  }, [orderId]);

  const currentStatus: OrderStatus = order?.status ?? "pending";
  const currentIndex = STATUS_FLOW.indexOf(currentStatus);

  return (
    <div className="min-h-screen flex flex-col items-center px-6 pt-16 pb-12 text-center">
      <div className="w-24 h-24 rounded-full bg-[#2E7D32] flex items-center justify-center animate-pop shadow-2xl">
        <Check size={48} className="text-white" strokeWidth={3} />
      </div>
      <h1 className="text-2xl font-bold text-[#2E7D32] mt-5">Order Placed!</h1>
      <p className="text-sm text-gray-500 mt-1">
        Your order <span className="font-semibold text-gray-800">#{orderId ?? "—"}</span> is confirmed.
      </p>
      <p className="text-sm text-gray-500 mt-1">
        Estimated delivery: <span className="font-semibold text-gray-800">30-45 minutes</span>
      </p>

      <div className="w-full max-w-sm mt-8 bg-white rounded-2xl border border-[#E5E7EB] p-5 text-left">
        <div className="flex items-center gap-2 mb-4">
          <Truck size={18} className="text-[#2E7D32]" />
          <h2 className="font-bold text-sm">Live Order Status</h2>
        </div>
        <ol className="space-y-4">
          {STATUS_FLOW.map((s, i) => {
            const reached = i <= currentIndex;
            const active = i === currentIndex;
            return (
              <li key={s} className="flex items-center gap-3">
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-bold ${
                    reached ? "bg-[#2E7D32] text-white" : "bg-gray-100 text-gray-400"
                  } ${active ? "ring-4 ring-green-100" : ""}`}
                >
                  {reached ? <Check size={14} strokeWidth={3} /> : i + 1}
                </div>
                <span
                  className={`text-sm ${
                    reached ? "text-gray-900 font-semibold" : "text-gray-400"
                  }`}
                >
                  {STATUS_LABEL[s]}
                </span>
              </li>
            );
          })}
        </ol>
        {!order && orderId && (
          <p className="text-xs text-gray-400 mt-4">Waiting for live updates…</p>
        )}
      </div>

      <div className="w-full max-w-sm mt-8 space-y-3">
        <Link to="/home" className="block text-sm text-[#2E7D32] font-semibold">
          Continue Shopping
        </Link>
      </div>
    </div>
  );
}
