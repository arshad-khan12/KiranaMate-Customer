import { createFileRoute, useNavigate, useRouter } from "@tanstack/react-router";
import { ArrowLeft, Heart, Star } from "lucide-react";
import { useState } from "react";
import { describe } from "../lib/data";
import { useProducts } from "../lib/products";
import { useCart, useWish } from "../lib/store";

export const Route = createFileRoute("/product/$id")({ component: Detail });

function Detail() {
  const { id } = Route.useParams();
  const products = useProducts();
  const product = products.find((p) => p.id === Number(id));
  const router = useRouter();
  const nav = useNavigate();
  const { add } = useCart();
  const { has, toggle } = useWish();
  const [qty, setQty] = useState(1);

  if (!product) return <div className="p-6">Product not found</div>;
  const liked = has(product.id);

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <header className="px-5 pt-5 flex items-center justify-between">
        <button onClick={() => router.history.back()} className="w-10 h-10 rounded-full border border-[#E5E7EB] flex items-center justify-center">
          <ArrowLeft size={18} />
        </button>
        <button onClick={() => toggle(product.id)} className="w-10 h-10 rounded-full border border-[#E5E7EB] flex items-center justify-center">
          <Heart size={18} className={liked ? "fill-red-500 text-red-500" : "text-gray-500"} />
        </button>
      </header>

      <div className="flex flex-col items-center mt-4 px-6">
        <div className="text-[80px] leading-none">{product.image}</div>
        <span className="mt-3 text-[11px] bg-green-50 text-[#2E7D32] px-3 py-1 rounded-full font-medium">{product.category}</span>
        <h1 className="text-xl font-bold mt-3 text-center">{product.name}</h1>
        <div className="flex items-center gap-1 mt-2">
          <Star size={14} className="fill-yellow-400 text-yellow-400" />
          <span className="text-sm font-semibold">{product.rating}</span>
          <span className="text-xs text-gray-400">({product.reviews} reviews)</span>
        </div>
        <div className="flex items-baseline gap-2 mt-3">
          <span className="text-sm text-gray-400 line-through">₹{product.oldPrice}</span>
          <span className="text-2xl font-bold text-[#2E7D32]">₹{product.price}</span>
          <span className="text-xs text-gray-500">/ {product.unit}</span>
        </div>

        <div className="flex items-center gap-4 mt-5 bg-gray-50 rounded-full px-2 py-1.5">
          <button onClick={() => setQty(Math.max(1, qty - 1))} className="w-8 h-8 rounded-full bg-white border border-[#E5E7EB] font-bold">−</button>
          <span className="font-semibold w-6 text-center">{qty}</span>
          <button onClick={() => setQty(qty + 1)} className="w-8 h-8 rounded-full bg-[#2E7D32] text-white font-bold">+</button>
        </div>
      </div>

      <div className="px-6 mt-6 flex-1">
        <h3 className="font-bold mb-2">Description</h3>
        <p className="text-sm text-gray-600 leading-relaxed">{describe(product)}</p>
      </div>

      <div className="p-5 flex gap-3 border-t border-[#E5E7EB]">
        <button
          onClick={() => { add(product, qty); nav({ to: "/cart" }); }}
          className="flex-1 border-2 border-[#2E7D32] text-[#2E7D32] font-semibold rounded-full py-3"
        >Add To Cart</button>
        <button
          onClick={() => { add(product, qty); nav({ to: "/checkout" }); }}
          className="flex-1 bg-[#2E7D32] text-white font-semibold rounded-full py-3"
        >Buy Now</button>
      </div>
    </div>
  );
}
