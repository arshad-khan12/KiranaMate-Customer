import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useCart } from "../lib/store";
import { CartLineItem } from "../components/ProductCard";
import { BottomNav } from "../components/BottomNav";

export const Route = createFileRoute("/cart")({ component: Cart });

function Cart() {
  const { items, subtotal } = useCart();
  const [code, setCode] = useState("");
  const [applied, setApplied] = useState<{ code: string; off: number } | null>(null);

  const delivery = subtotal >= 500 || subtotal === 0 ? 0 : 30;
  const discount = applied ? applied.off : 0;
  const total = Math.max(0, subtotal + delivery - discount);

  function apply() {
    const c = code.trim().toUpperCase();
    if (c === "SAVE25") setApplied({ code: c, off: Math.round(subtotal * 0.25) });
    else if (c === "FLAT50") setApplied({ code: c, off: 50 });
    else setApplied(null);
  }

  return (
    <div className="min-h-screen pb-32">
      <header className="px-5 pt-6">
        <h1 className="text-xl font-bold">My Cart</h1>
        <p className="text-xs text-gray-500">{items.length} item{items.length !== 1 ? "s" : ""}</p>
      </header>

      {items.length === 0 ? (
        <div className="px-6 mt-24 text-center">
          <div className="text-6xl mb-3">🛒</div>
          <h2 className="font-bold">Your cart is empty</h2>
          <p className="text-sm text-gray-500 mt-1">Add fresh groceries to get started.</p>
          <Link to="/home" className="inline-block mt-6 bg-[#2E7D32] text-white font-semibold rounded-full px-6 py-3 text-sm">Shop Now</Link>
        </div>
      ) : (
        <>
          <div className="px-5 mt-4 space-y-3">
            {items.map((i) => <CartLineItem key={i.product.id} id={i.product.id} />)}
          </div>

          <div className="mx-5 mt-5 bg-white rounded-2xl border border-[#E5E7EB] p-4">
            <div className="flex gap-2">
              <input
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="Voucher code (SAVE25 / FLAT50)"
                className="flex-1 bg-gray-50 border border-[#E5E7EB] rounded-full px-4 py-2 text-sm outline-none"
              />
              <button onClick={apply} className="bg-[#2E7D32] text-white text-sm font-semibold rounded-full px-4">Apply</button>
            </div>
            {applied && <p className="text-xs text-[#2E7D32] mt-2">✓ {applied.code} applied — saved ₹{applied.off}</p>}
            {code && !applied && code.length > 2 && <p className="text-xs text-red-500 mt-2">Invalid code</p>}
          </div>

          <div className="mx-5 mt-4 bg-white rounded-2xl border border-[#E5E7EB] p-4 space-y-2 text-sm">
            <Row label="Subtotal" value={`₹${subtotal}`} />
            <Row label={`Delivery Fee ${subtotal >= 500 ? "(Free over ₹500)" : ""}`} value={delivery === 0 ? "FREE" : `₹${delivery}`} />
            {discount > 0 && <Row label="Discount" value={`-₹${discount}`} green />}
            <div className="border-t border-dashed border-[#E5E7EB] pt-2 flex justify-between font-bold">
              <span>Grand Total</span>
              <span className="text-[#2E7D32]">₹{total}</span>
            </div>
          </div>

          <div className="fixed bottom-16 left-1/2 -translate-x-1/2 w-full max-w-[390px] p-4 bg-white border-t border-[#E5E7EB]">
            <Link to="/checkout" className="block w-full bg-[#2E7D32] text-white text-center font-semibold rounded-full py-3.5">
              Checkout · ₹{total}
            </Link>
          </div>
        </>
      )}

      <BottomNav />
    </div>
  );
}

function Row({ label, value, green }: { label: string; value: string; green?: boolean }) {
  return (
    <div className="flex justify-between">
      <span className="text-gray-500">{label}</span>
      <span className={green ? "text-[#2E7D32] font-semibold" : "font-medium"}>{value}</span>
    </div>
  );
}
