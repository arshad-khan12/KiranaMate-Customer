import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Bell, Search, MapPin, Star, Trophy } from "lucide-react";
import { useState, useMemo } from "react";
import { shops, type Shop } from "../lib/shops";
import { BottomNav } from "../components/BottomNav";
import { useAuth } from "../lib/auth";
import { AdBanner } from "../components/AdBanner";

export const Route = createFileRoute("/shops")({ component: ShopDiscovery });

type Filter = "All" | "TopRated" | "OpenNow" | "FreeDelivery" | "Nearest";

function ShopDiscovery() {
  const { name, isPro, fbUser, loading } = useAuth();
  const nav = useNavigate();
  const [filter, setFilter] = useState<Filter>("All");

  // Guard: if not signed in, send to signin
  if (!loading && !fbUser) {
    if (typeof window !== "undefined") nav({ to: "/signin" });
  }

  const initials = (name || "U").split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase();

  const list = useMemo(() => {
    let l = [...shops];
    if (filter === "TopRated") l = l.filter((s) => s.rating >= 4.7).sort((a, b) => b.rating - a.rating);
    else if (filter === "OpenNow") l = l.filter((s) => s.isOpen);
    else if (filter === "FreeDelivery") l = l.filter((s) => s.freeDeliveryAbove > 0);
    else if (filter === "Nearest") l = l.sort((a, b) => parseFloat(a.distance) - parseFloat(b.distance));
    return l;
  }, [filter]);

  const featured = shops.filter((s) => s.isFeatured);

  return (
    <div className="min-h-screen bg-[#F9F9F9] pb-28">
      <header className="bg-white sticky top-0 z-10 px-5 pt-5 pb-3 border-b border-[#F3F4F6]">
        <div className="flex items-center justify-between">
          <button className="flex items-center gap-1 text-sm font-semibold">
            <MapPin size={16} className="text-[#2E7D32]" /> Nagpur <span className="text-gray-400">▾</span>
          </button>
          <div className="flex items-center gap-3">
            <button className="w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center">
              <Bell size={16} className="text-gray-600" />
            </button>
            <Link to="/profile" className="w-9 h-9 rounded-full bg-[#2E7D32] text-white text-xs font-bold flex items-center justify-center">
              {initials}
            </Link>
          </div>
        </div>
        <Link to="/search" className="mt-3 flex items-center gap-2 bg-gray-100 rounded-full px-4 py-2.5">
          <Search size={16} className="text-gray-400" />
          <span className="text-xs text-gray-500">Search shops or products...</span>
        </Link>
      </header>

      <div className="px-5 mt-3 overflow-x-auto no-scrollbar">
        <div className="flex gap-2 w-max">
          {([
            ["All", "All"], ["TopRated", "⭐ Top Rated"], ["OpenNow", "🟢 Open Now"],
            ["FreeDelivery", "🆓 Free Delivery"], ["Nearest", "📍 Nearest"],
          ] as [Filter, string][]).map(([key, label]) => (
            <button key={key} onClick={() => setFilter(key)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-medium whitespace-nowrap border ${
                filter === key ? "bg-[#2E7D32] text-white border-[#2E7D32]" : "bg-white text-gray-600 border-[#E5E7EB]"
              }`}>{label}</button>
          ))}
        </div>
      </div>

      {!isPro && <div className="px-5 mt-3"><AdBanner /></div>}

      {featured.length > 0 && (
        <section className="mt-5">
          <h2 className="px-5 font-bold text-sm">⭐ Featured Shops</h2>
          <div className="mt-2 px-5 overflow-x-auto no-scrollbar">
            <div className="flex gap-3 w-max pb-1">
              {featured.map((s) => <FeaturedCard key={s.id} shop={s} />)}
            </div>
          </div>
        </section>
      )}

      <section className="mt-5 px-5">
        <h2 className="font-bold text-sm">All Shops Near You</h2>
        <div className="mt-3 space-y-3">
          {list.map((s) => <ShopCard key={s.id} shop={s} />)}
          {list.length === 0 && <p className="text-center text-xs text-gray-400 py-8">No shops match this filter</p>}
        </div>
      </section>

      <BottomNav />
    </div>
  );
}

function FeaturedCard({ shop }: { shop: Shop }) {
  return (
    <Link to="/shop/$shopId" params={{ shopId: shop.id }}
      className="block w-60 bg-white rounded-2xl overflow-hidden border border-[#F3F4F6]"
      style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.08)" }}>
      <div className="h-24 bg-gradient-to-br from-[#2E7D32] to-[#4CAF50] relative p-3 text-white flex flex-col justify-end">
        <span className="absolute top-2 right-2 bg-amber-400 text-amber-900 text-[10px] font-bold px-2 py-0.5 rounded-full">⭐ Featured</span>
        <p className="font-bold text-sm leading-tight">{shop.name}</p>
      </div>
      <div className="p-3">
        <div className="flex justify-between items-center text-xs">
          <span className="text-gray-500">{shop.area}</span>
          <span className="font-semibold text-amber-600 flex items-center gap-0.5">
            <Star size={11} fill="currentColor" /> {shop.rating}
          </span>
        </div>
      </div>
    </Link>
  );
}

function ShopCard({ shop }: { shop: Shop }) {
  return (
    <Link to="/shop/$shopId" params={{ shopId: shop.id }}
      className="block bg-white rounded-2xl overflow-hidden border border-[#F3F4F6]"
      style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.08)" }}>
      <div className="h-20 bg-gradient-to-r from-[#2E7D32] to-[#4CAF50] relative px-4 flex items-center">
        <p className="text-white font-bold text-base">{shop.name}</p>
        <div className="absolute top-2 right-2 flex gap-1">
          {shop.isFeatured && <span className="bg-amber-400 text-amber-900 text-[10px] font-bold px-2 py-0.5 rounded-full">⭐ Featured</span>}
          {shop.isSuperShop && <span className="bg-white/90 text-[#2E7D32] text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-0.5"><Trophy size={10} /> SuperShop</span>}
        </div>
      </div>
      <div className="p-3.5 space-y-1.5">
        <div className="flex items-center justify-between">
          <span className="font-bold text-sm">{shop.name}</span>
          <span className="text-amber-600 text-xs font-semibold flex items-center gap-0.5">
            <Star size={11} fill="currentColor" /> {shop.rating} ({shop.reviews})
          </span>
        </div>
        <div className="flex items-center justify-between text-xs text-gray-500">
          <span>{shop.area}</span>
          <span>{shop.distance}</span>
        </div>
        <div className="flex items-center justify-between">
          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${shop.isOpen ? "bg-green-50 text-green-700" : "bg-gray-100 text-gray-500"}`}>
            {shop.isOpen ? "🟢 Open" : "🔴 Closed"}
          </span>
          <span className="text-[11px] text-teal-700">🕐 Next: {shop.nextSlot}</span>
        </div>
        <div className="flex items-center justify-between text-[11px] pt-1 border-t border-[#F3F4F6]">
          <span className="text-gray-700">
            {shop.freeDeliveryAbove > 0 ? `🎉 Free delivery above ₹${shop.freeDeliveryAbove}` : `🛵 ₹${shop.deliveryFee} delivery`}
          </span>
          <span className="text-gray-400">Min ₹{shop.minOrder}</span>
        </div>
      </div>
    </Link>
  );
}
