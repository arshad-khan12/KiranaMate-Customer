import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { ArrowLeft, Crown, Check } from "lucide-react";
import { useState } from "react";
import { useAuth } from "../lib/auth";

export const Route = createFileRoute("/pro")({ component: ProUpgrade });

const FEATURES = [
  "No ads — ever",
  "Order from 3 devices",
  "Priority delivery slots",
  "Unlimited order history",
  "Saved grocery lists (up to 5)",
  "One-tap Reorder",
  "Price drop alerts",
  "Early access to new features",
];

function ProUpgrade() {
  const router = useRouter();
  const { userDoc, isPro, activateTrial, fbUser } = useAuth();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  async function startTrial() {
    if (!fbUser) { router.navigate({ to: "/signin" }); return; }
    setBusy(true); setErr("");
    try {
      await activateTrial();
      router.navigate({ to: "/shops" });
    } catch (e: unknown) {
      setErr((e as Error)?.message || "Could not start trial");
    } finally { setBusy(false); }
  }

  return (
    <div className="min-h-screen bg-white pb-10">
      <header className="px-5 pt-5 flex items-center gap-3">
        <button onClick={() => router.history.back()} className="w-10 h-10 rounded-full border border-[#E5E7EB] flex items-center justify-center">
          <ArrowLeft size={18} />
        </button>
      </header>

      <div className="px-6 mt-4 text-center">
        <Crown size={48} className="text-amber-400 mx-auto" />
        <h1 className="mt-3 text-2xl font-extrabold text-amber-500">KiranaMate Pro</h1>
        <p className="text-sm text-gray-500 mt-1">Upgrade to unlock everything</p>
      </div>

      {isPro ? (
        <div className="mx-5 mt-6 bg-amber-50 border border-amber-200 rounded-2xl p-4 text-center">
          <p className="text-sm font-semibold text-amber-700">👑 You are a Pro member</p>
          {userDoc?.planExpiry && (
            <p className="text-xs text-amber-600 mt-1">Active until {new Date(userDoc.planExpiry).toLocaleDateString()}</p>
          )}
        </div>
      ) : (
        !userDoc?.trialUsed && (
          <div className="mx-5 mt-5 rounded-2xl bg-green-50 border border-green-200 p-4 text-center">
            <p className="text-sm font-semibold text-[#2E7D32]">🎯 Start FREE 7-day trial</p>
            <p className="text-xs text-green-700 mt-1">No payment needed to start</p>
          </div>
        )
      )}

      <ul className="mx-5 mt-5 bg-white border border-[#E5E7EB] rounded-2xl divide-y divide-[#F3F4F6]">
        {FEATURES.map((f) => (
          <li key={f} className="flex items-center gap-3 px-4 py-3">
            <Check size={16} className="text-[#16A34A]" />
            <span className="text-sm text-gray-800">{f}</span>
          </li>
        ))}
      </ul>

      <div className="mx-5 mt-5 grid grid-cols-2 gap-3">
        <div className="rounded-2xl border border-[#E5E7EB] p-4 text-center">
          <p className="text-xs text-gray-500">Monthly</p>
          <p className="font-bold text-lg mt-1">₹49<span className="text-xs text-gray-500">/mo</span></p>
        </div>
        <div className="rounded-2xl border-2 border-[#2E7D32] bg-green-50 p-4 text-center relative">
          <span className="absolute -top-2 right-2 bg-[#2E7D32] text-white text-[9px] font-bold px-2 py-0.5 rounded-full">SAVE ₹189</span>
          <p className="text-xs text-[#2E7D32] font-semibold">Yearly</p>
          <p className="font-bold text-lg mt-1 text-[#2E7D32]">₹399<span className="text-xs">/yr</span></p>
        </div>
      </div>

      {err && <p className="text-xs text-red-600 text-center mt-3">{err}</p>}

      {!isPro && (
        <div className="px-5 mt-6 space-y-2">
          <button onClick={startTrial} disabled={busy || !!userDoc?.trialUsed}
            className="w-full bg-[#2E7D32] disabled:opacity-60 text-white font-semibold rounded-full py-3.5">
            {busy ? "Activating..." : userDoc?.trialUsed ? "Trial already used" : "Start 7-Day Free Trial"}
          </button>
          <Link to="/shops" className="block text-center text-xs text-gray-500 mt-2">Continue with Free</Link>
        </div>
      )}
    </div>
  );
}
